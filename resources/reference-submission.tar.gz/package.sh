#!/bin/bash

/bin/tar czf submission.tar.gz package.sh run.sh compile.sh reference_solution.py
